<?php

$conn = mysql_connect("localhost", "teste", "teste");
if (!$conn) {
    echo "N�o foi poss�vel conectar ao banco de dados: " . mysql_error();
    exit;
}
mysql_set_charset('UTF-8');

// Selecionando banco
if (!mysql_select_db("empresa")) {
    echo "N�o foi poss�vel selecionar empresa: " . mysql_error();
    exit;
}



$sql = "INSERT INTO salario (nome, salario) VALUES
		('RAIMUNDO', 600.0),
		('LOPES', 600.0),
		('SOUZA', 2640.60),
		('FRANCISCO', 600.0)";



$result = mysql_query($sql);

if ($result) {
	echo "Os registros foram inseridos com sucesso.";
} else {
    echo "N�o foi poss�vel executar ($sql) no banco de dados: " . mysql_error();
    exit;
}

mysql_free_result($result);

?>
