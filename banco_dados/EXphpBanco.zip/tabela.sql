CREATE TABLE IF NOT EXISTS `salario` (
  `nome` varchar(255) NOT NULL,
  `salario` float NOT NULL,
  PRIMARY KEY (`nome`)
);
