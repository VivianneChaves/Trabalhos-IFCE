<?php

$conn = mysql_connect("localhost", "teste", "teste");

if (!$conn) {
    echo "N�o foi poss�vel conectar ao banco de dados: " . mysql_error();
    exit;
}

// Selecionando banco
if (!mysql_select_db("empresa")) {
    echo "N�o foi poss�vel selecionar empresa: " . mysql_error();
    exit;
}




$sql = "SELECT nome, salario FROM salario";


$result = mysql_query($sql);

if (!$result) {
    echo "N�o foi poss�vel executar a consulta ($sql) no banco de dados: " . mysql_error();
    exit;
}

if (mysql_num_rows($result) == 0) {
    echo "N�o foram encontradas linhas, nada para mostrar";
    exit;
}

// Enquanto uma linha de dados existir, coloca esta linha em $row como uma matriz associativa
while ($row = mysql_fetch_assoc($result)) {
    echo 'Nome: '.$row["nome"]."<br>";
    echo 'Salario: '.$row["salario"].'<br><br>';
}

mysql_free_result($result);

?>
